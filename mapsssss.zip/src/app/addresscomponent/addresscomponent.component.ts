import { MapServiceService } from "./../services/map-service.service";
import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
@Component({
  selector: "app-addresscomponent",
  templateUrl: "./addresscomponent.component.html",
  styleUrls: ["./addresscomponent.component.css"]
})
export class AddresscomponentComponent implements OnInit {
  latitude;
  longitude;
  placeresult;
  tempobj;
  placeid1;
  finalresult;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: MapServiceService
  )
  {}
  ngOnInit() {
    this.route.params.subscribe(params => {
      console.log(params);
      this.latitude = params.latitude;
      this.longitude = params.longitude;
      console.log("params----------->", params.latitude, params.longitude);
    });
    this.getplaceid();
  }
  getplaceid() {
    this.service.gethotels(this.longitude, this.latitude).subscribe(res => {
      //console.log("placeid----->",res.plus_code.results[1].place_id);
      console.log('getplace id---->',res);
      this.tempobj = res;
      console.log("@@@@@@@@@@@@@@", this.tempobj.results[1].place_id);

      this.placeid1 = this.tempobj.results[1].place_id;
      console.log("final placeid--->", this.placeid1);
      this.getdetails();
    });
  }
  getdetails() {
    console.log("get details --->", this.placeid1);
    
    this.service.getaddress(this.placeid1).subscribe(res => {
      console.log('#333333333333333333',res);
      console.log("---------------->>>",res.result);
      this.finalresult=res.result;
    });
  }
}
